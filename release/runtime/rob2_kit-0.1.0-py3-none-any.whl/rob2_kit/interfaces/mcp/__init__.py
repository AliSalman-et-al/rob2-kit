"""Static stdio MCP transport."""
