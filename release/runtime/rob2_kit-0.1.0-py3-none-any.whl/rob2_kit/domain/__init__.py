"""Immutable domain contracts."""
